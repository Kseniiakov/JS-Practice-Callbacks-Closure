"use strict";

// Функция-колбэк
// 1) Создайте функцию с двумя параметрами:
// первый принимает число,
// второй принимает функцию-колбэк.
// Функцию колбэк вызвать и передать ей число.

// const myCallback = (a) => {
//     const squared = a*a;
//     return squared;
// };

// function myFunc(num, callback){
//     const resultCallback = callback(num);
//     const resultText = `${resultCallback} это квадрат числа ${num}`
//     return resultText;
// }

// const result = myFunc(5, myCallback);
// console.log(result);

// 2) Создайте функцию которая принимает массив, и функцию-колбэк
// Вызовите функцию-колбэк столько раз сколько ячеек в массиве.

// const myCallback = (a) => {
//     const squared = a*a;
//     return squared;
// };

// function myFunc(arr, callback) {
//     for(let i = 0; i < arr.length; i++) {
//         const resultCallback = callback(arr[i]);
//         console.log(resultCallback);
//     };
// };

// myFunc([1,2,3,4,5,6,7,8,9,10], myCallback);

// 3) Создайте функцию которая принимает:
// массив,
// число,
// функцию-колбэк.
// Найдите число в массиве, если нашли то вызовите функцию-колбэк.

// const myCallback = (a) => {
//     const result = a+a;
//     return result;
// }

// function findNumber(arr, num, callback) {
//     for(let i = 0; i < arr.length; i++) {
//         if(arr[i] === num) {
//             const resultCallback = callback(arr[i]);
//             return resultCallback;
//         }
//     };
// };

// const resultFunc = findNumber([1,2,3,4,5,6,7,8, 88, 9,10],88, myCallback);
// console.log(resultFunc);

// 4) * Реализуйте функцию map используя параметры: массив, 
// функцию-колбэк. Возвращает новый массив состоящий из значений 
// полученных  в результате вызова колбэка.

// const myArr = [10,12,14,16,18,20];

// const myCallback = (elem) => {
//     const result = elem/2;
//     return result;
// };

// function myMap(arr, callback) {
//     const newArr = [];
//     for(let i = 0; i < arr.length; i++) {
//         const resultCallback = callback(arr[i]);
//         newArr.push(resultCallback);
//     }
//     return newArr;
// }

// const result = myMap(myArr, myCallback);
// console.log(result);

// 5) * Реализуйте функцию filter, которая принимает массив 
// и функцию-колбэк. Возвращает новый массив в который помещает
// только элементы прошедшие проверку через колбэк (вернул true)

// const myArr = [1,2,3,4,5,6];

// const myCallback = (elem) => {
//     if(elem % 2 === 0) {
//         return elem;
//     }
// };

// function myMap(arr, callback) {
//     const newArr = [];
//     for(let i = 0; i < arr.length; i++) {
//         const resultCallback = callback(arr[i]);
//         if(resultCallback !== undefined) {
//             newArr.push(resultCallback);
//         }
//     }
//     return newArr;
// }

// const result = myMap(myArr, myCallback);
// console.log(result);